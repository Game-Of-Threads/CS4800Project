import React, { Component } from 'react';

const AppContext = React.createContext({
  addNote : () => {}
});

export default AppContext;
